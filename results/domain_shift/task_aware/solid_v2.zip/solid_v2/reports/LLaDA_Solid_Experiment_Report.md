# LLaDA Solid Experiment Report

## 1. Problem and Thesis

我们不把贡献写成“改 LLaDA 架构”。主张是：LLaDA 的 masked diffusion trajectory 暴露了不同任务、不同样本的反向去噪预算需求，因此可以用 task/sample-aware controller 在 accuracy-cost 之间做风险受控分配。

核心方法是 **Calibrated Forward-aware Risk Controller**：先用低预算 probe 估计 posterior confidence 与 label disagreement，再按风险路由到 cheap / medium / full reverse budget。LoRA 只作为辅助审计，用来回答普通下游微调是否能解决同一类行为边界。

## 2. Exploration Process

1. 先跑 typed final-label benchmark，避免 prompt 格式混淆。
2. 再做 old adaptive router，发现它很省算力，但 WinoGrande 上会越过 full-budget 边界。
3. 接着做 forward-aware probe，把早期 confidence、fallback 与最终正确性关联起来。
4. 最后加入 calibration threshold 与 multi-choice disagreement policy，形成主方法。
5. 用 PubMedQA/C-Eval 作为负例边界：证明 controller 不是万能调参，而是在可由 reverse budget 影响的区域有效。

## 3. Method

Controller 的 inference loop 可以抽象为三段：

- **Forward probe**：用 cheap reverse trajectory 得到初始 label posterior 与 top probability。
- **Scout decision**：检测 binary 任务中的低置信度、近邻混淆，以及 multi-choice disagreement。
- **Calibrated route**：在 cheap / medium / full 预算之间选择；高风险 binary 样本保守 fallback，多选任务默认忽略轻微 disagreement，减少不必要的 full-budget 调用。

## 4. Mathematical Idea

离散扩散可以看成 token 状态空间上的连续时间马尔可夫链或其离散化近似。反向生成时，模型给出近似 posterior / score，用有限步数从 masked/corrupted state 回到数据分布。这里的关键量不是单个 token 的局部置信度，而是最终 label 的 hitting time：达到并稳定在最终答案所需的反向步数。

因此 controller 优化的是一个 cost-sensitive risk：

`min_pi E[1{y_hat_pi(x) != y} + lambda C(pi, x)]`

其中策略 `pi` 根据 probe trajectory 的 uncertainty 选择预算。若某任务 hitting time 分布更晚，比如 WinoGrande，策略应更保守；若某任务早期 label posterior 已稳定，比如 CommonsenseQA，则可以更激进地节省预算。

## 5. Main 1000 Results

| Method | Task | Acc | 95% CI | Avg Calls | Seconds | Route/Fallback |
|---|---|---:|---:|---:|---:|---|
| 32step | WinoGrande | 0.756 | [0.728, 0.782] | 32.000 | 1555.6 | `{"fixed": 1.0}` |
| 32step | CommonsenseQA | 0.819 | [0.794, 0.842] | 32.000 | 1550.2 | `{"fixed": 1.0}` |
| old_adaptive | WinoGrande | 0.736 | [0.708, 0.762] | 9.363 | 408.5 | `{"fallback": 0.011, "fixed": 0.989}` |
| old_adaptive | CommonsenseQA | 0.816 | [0.791, 0.839] | 9.858 | 432.3 | `{"fallback": 0.026, "fixed": 0.974}` |
| forward_aware | WinoGrande | 0.756 | [0.728, 0.782] | 17.560 | 847.7 | `{"accepted_fast": 0.648, "post_fallback": 0.014, "pre_fallback": 0.338}` |
| forward_aware | CommonsenseQA | 0.818 | [0.793, 0.841] | 10.824 | 523.6 | `{"accepted_fast": 0.943, "post_fallback": 0.057}` |
| calibrated | WinoGrande | 0.756 | [0.728, 0.782] | 17.560 | 852.4 | `{"32": 0.338, "8": 0.648, "8->32": 0.014}` |
| calibrated | CommonsenseQA | 0.817 | [0.792, 0.840] | 9.064 | 442.0 | `{"8": 0.998, "8->32": 0.002}` |

## Paired McNemar

| Task | Reference | Candidate | n | Ref Only | Cand Only | Net | p |
|---|---|---|---:|---:|---:|---:|---:|
| WinoGrande | 32step | calibrated | 1000 | 3 | 3 | 0 | 1.0000 |
| CommonsenseQA | 32step | calibrated | 1000 | 8 | 6 | -2 | 0.7905 |
| WinoGrande | old_adaptive | calibrated | 1000 | 25 | 45 | 20 | 0.0225 |
| CommonsenseQA | old_adaptive | calibrated | 1000 | 0 | 1 | 1 | 1.0000 |
| WinoGrande | forward_aware | calibrated | 1000 | 0 | 0 | 0 | 1.0000 |
| CommonsenseQA | forward_aware | calibrated | 1000 | 4 | 3 | -1 | 1.0000 |

## 6. Threshold Robustness

| Threshold | Task | Acc | Avg Calls | Route Rates |
|---:|---|---:|---:|---|
| 0.60 | WinoGrande | 0.754 | 15.704 | `{"32": 0.194, "8": 0.742, "8->32": 0.064}` |
| 0.60 | CommonsenseQA | 0.812 | 9.000 | `{"8": 1.0}` |
| 0.65 | WinoGrande | 0.756 | 16.456 | `{"32": 0.268, "8": 0.7, "8->32": 0.032}` |
| 0.65 | CommonsenseQA | 0.812 | 9.000 | `{"8": 1.0}` |
| 0.70 | WinoGrande | 0.756 | 17.768 | `{"32": 0.344, "8": 0.64, "8->32": 0.016}` |
| 0.70 | CommonsenseQA | 0.812 | 9.000 | `{"8": 1.0}` |
| 0.75 | WinoGrande | 0.756 | 20.568 | `{"32": 0.466, "8": 0.522, "8->32": 0.012}` |
| 0.75 | CommonsenseQA | 0.812 | 9.000 | `{"8": 1.0}` |
| 0.80 | WinoGrande | 0.756 | 22.936 | `{"32": 0.578, "8": 0.42, "8->32": 0.002}` |
| 0.80 | CommonsenseQA | 0.812 | 9.000 | `{"8": 1.0}` |

## 7. Boundary Negative Cases

| Method | Task | Acc | Avg Calls | Notes |
|---|---|---:|---:|---|
| 8step | PubMedQA | 0.557 |  | label-prior / knowledge-boundary probe |
| 8step | C-Eval CN | 0.585 |  | label-prior / knowledge-boundary probe |
| 32step | PubMedQA | 0.660 | 32.000 | label-prior / knowledge-boundary probe |
| 32step | C-Eval CN | 0.585 | 32.000 | label-prior / knowledge-boundary probe |
| calibrated | PubMedQA | 0.680 | 33.000 | label-prior / knowledge-boundary probe |
| calibrated | C-Eval CN | 0.585 | 33.000 | label-prior / knowledge-boundary probe |

## 8. LoRA Gain Audit

| Method | Task | Value | n |
|---|---|---:|---:|
| llada_base | MMLU-Pro | 0.440 | 100 |
| llada_base | PubMedQA | 0.720 | 100 |
| llada_base | C-Eval CN | 0.560 | 100 |
| llada_base | SciQ | 0.880 | 100 |
| llada_base | WinoGrande | 0.780 | 100 |
| llada_base | CommonsenseQA | 0.790 | 100 |
| llada_lora | MMLU-Pro | 0.440 | 100 |
| llada_lora | PubMedQA | 0.720 | 100 |
| llada_lora | C-Eval CN | 0.540 | 100 |
| llada_lora | SciQ | 0.880 | 100 |
| llada_lora | WinoGrande | 0.780 | 100 |
| llada_lora | CommonsenseQA | 0.800 | 100 |
| qwen_base | MMLU-Pro | 0.350 | 100 |
| qwen_base | PubMedQA | 0.570 | 100 |
| qwen_base | C-Eval CN | 0.730 | 100 |
| qwen_base | SciQ | 0.930 | 100 |
| qwen_base | WinoGrande | 0.700 | 100 |
| qwen_base | CommonsenseQA | 0.800 | 100 |
| ddm_lora_gain | C-Eval CN | -0.020 | 100 |
| ddm_lora_gain | CommonsenseQA | 0.010 | 100 |
| ddm_lora_gain | MMLU-Pro | 0.000 | 100 |
| ddm_lora_gain | PubMedQA | 0.000 | 100 |
| ddm_lora_gain | SciQ | 0.000 | 100 |
| ddm_lora_gain | WinoGrande | 0.000 | 100 |

## 9. Trajectory and Error Analysis

| Task | n | Mean First Final Step | Mean Flip Count | Late Instability |
|---|---:|---:|---:|---:|
| CommonsenseQA | 200 | 7.44 | 0.715 | 0.715 |
| WinoGrande | 200 | 15.89 | 0.345 | 0.325 |

### Error Taxonomy

| Comparison | Task | Bucket | Count | Rate | Controller Route Counts |
|---|---|---|---:|---:|---|
| full_budget_vs_controller | WinoGrande | 32step_only | 3 | 0.003 | `{"8": 3}` |
| full_budget_vs_controller | WinoGrande | both_correct | 753 | 0.753 | `{"32": 222, "8": 521, "8->32": 10}` |
| full_budget_vs_controller | WinoGrande | both_wrong | 241 | 0.241 | `{"32": 116, "8": 121, "8->32": 4}` |
| full_budget_vs_controller | WinoGrande | calibrated_only | 3 | 0.003 | `{"8": 3}` |
| full_budget_vs_controller | CommonsenseQA | 32step_only | 8 | 0.008 | `{"8": 8}` |
| full_budget_vs_controller | CommonsenseQA | both_correct | 811 | 0.811 | `{"8": 809, "8->32": 2}` |
| full_budget_vs_controller | CommonsenseQA | both_wrong | 175 | 0.175 | `{"8": 175}` |
| full_budget_vs_controller | CommonsenseQA | calibrated_only | 6 | 0.006 | `{"8": 6}` |
| old_router_vs_controller | WinoGrande | both_correct | 711 | 0.711 | `{"32": 182, "8": 524, "8->32": 5}` |
| old_router_vs_controller | WinoGrande | both_wrong | 219 | 0.219 | `{"32": 92, "8": 124, "8->32": 3}` |
| old_router_vs_controller | WinoGrande | calibrated_only | 45 | 0.045 | `{"32": 40, "8->32": 5}` |
| old_router_vs_controller | WinoGrande | old_adaptive_only | 25 | 0.025 | `{"32": 24, "8->32": 1}` |
| old_router_vs_controller | CommonsenseQA | both_correct | 816 | 0.816 | `{"8": 814, "8->32": 2}` |
| old_router_vs_controller | CommonsenseQA | both_wrong | 183 | 0.183 | `{"8": 183}` |
| old_router_vs_controller | CommonsenseQA | calibrated_only | 1 | 0.001 | `{"8": 1}` |
| uncalibrated_vs_calibrated | WinoGrande | both_correct | 756 | 0.756 | `{"32": 222, "8": 524, "8->32": 10}` |
| uncalibrated_vs_calibrated | WinoGrande | both_wrong | 244 | 0.244 | `{"32": 116, "8": 124, "8->32": 4}` |
| uncalibrated_vs_calibrated | CommonsenseQA | both_correct | 814 | 0.814 | `{"8": 812, "8->32": 2}` |
| uncalibrated_vs_calibrated | CommonsenseQA | both_wrong | 179 | 0.179 | `{"8": 179}` |
| uncalibrated_vs_calibrated | CommonsenseQA | calibrated_only | 3 | 0.003 | `{"8": 3}` |
| uncalibrated_vs_calibrated | CommonsenseQA | forward_aware_only | 4 | 0.004 | `{"8": 4}` |

## 10. Limitations and Final Takeaway

- 不声称修改 LLaDA 架构；这是 inference-loop/controller 改进。
- WinoGrande 用于展示 high-risk binary semantic binding 需要保守预算控制。
- CommonsenseQA 用于展示 low-risk multi-choice 可减少不必要 fallback。
- PubMedQA/C-Eval 作为边界负例：采样预算不能弥补 label bias 或知识缺口。
- LoRA gain audit 不追求 SOTA，只验证“普通参数高效微调是否能替代 trajectory-aware controller”。

最终可讲成一句话：**我们没有把 LLaDA 改成另一个模型，而是把 masked diffusion 的反向轨迹从一次性生成过程变成可观测、可校准、可控成本的决策过程。**